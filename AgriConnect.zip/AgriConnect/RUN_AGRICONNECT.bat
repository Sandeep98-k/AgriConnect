@echo off
title AgriConnect Spring Boot Application
echo ========================================================
echo         AgriConnect Spring Boot Application
echo ========================================================
echo Starting AgriConnect server on http://localhost:5000 ...
echo.
cd /d "%~dp0"
call mvnw.cmd clean spring-boot:run
pause
