package com.agriconnect.repository;

import com.agriconnect.model.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class OrderRepository {

    private final JdbcTemplate jdbcTemplate;

    public OrderRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Order> orderRowMapper = (rs, rowNum) -> new Order(
            rs.getLong("id"),
            rs.getLong("buyer_id"),
            rs.getString("buyer_name"),
            rs.getLong("farmer_id"),
            rs.getLong("product_id"),
            rs.getString("product_title"),
            rs.getInt("quantity"),
            rs.getDouble("unit_price"),
            rs.getDouble("total_price"),
            rs.getString("status"),
            rs.getString("delivery_address"),
            rs.getString("payment_method"),
            rs.getString("order_date")
    );

    public int save(Order order) {
        return jdbcTemplate.update(
                "INSERT INTO orders (buyer_id, buyer_name, farmer_id, product_id, product_title, quantity, unit_price, total_price, status, delivery_address, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                order.getBuyerId(), order.getBuyerName(), order.getFarmerId(), order.getProductId(),
                order.getProductTitle(), order.getQuantity(), order.getUnitPrice(), order.getTotalPrice(),
                order.getStatus(), order.getDeliveryAddress(), order.getPaymentMethod()
        );
    }

    public List<Order> findByBuyerId(Long buyerId) {
        return jdbcTemplate.query("SELECT * FROM orders WHERE buyer_id = ? ORDER BY id DESC", orderRowMapper, buyerId);
    }

    public List<Order> findByFarmerId(Long farmerId) {
        return jdbcTemplate.query("SELECT * FROM orders WHERE farmer_id = ? ORDER BY id DESC", orderRowMapper, farmerId);
    }

    public List<Order> findAll() {
        return jdbcTemplate.query("SELECT * FROM orders ORDER BY id DESC", orderRowMapper);
    }

    public int updateStatus(Long orderId, String status) {
        return jdbcTemplate.update("UPDATE orders SET status = ? WHERE id = ?", status, orderId);
    }

    public int countOrders() {
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM orders", Integer.class);
        return count != null ? count : 0;
    }
}
