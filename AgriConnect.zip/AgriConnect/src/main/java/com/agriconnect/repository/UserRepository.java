package com.agriconnect.repository;

import com.agriconnect.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserRepository {

    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<User> userRowMapper = (rs, rowNum) -> new User(
            rs.getLong("id"),
            rs.getString("name"),
            rs.getString("email"),
            rs.getString("password"),
            rs.getString("role"),
            rs.getString("phone"),
            rs.getString("location"),
            rs.getString("avatar")
    );

    public User findByEmail(String email) {
        List<User> users = jdbcTemplate.query("SELECT * FROM users WHERE email = ?", userRowMapper, email);
        return users.isEmpty() ? null : users.get(0);
    }

    public User findById(Long id) {
        List<User> users = jdbcTemplate.query("SELECT * FROM users WHERE id = ?", userRowMapper, id);
        return users.isEmpty() ? null : users.get(0);
    }

    public List<User> findAll() {
        return jdbcTemplate.query("SELECT * FROM users ORDER BY id DESC", userRowMapper);
    }

    public int save(User user) {
        return jdbcTemplate.update(
                "INSERT INTO users (name, email, password, role, phone, location, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)",
                user.getName(), user.getEmail(), user.getPassword(), user.getRole(), user.getPhone(), user.getLocation(), user.getAvatar()
        );
    }

    public int update(User user) {
        return jdbcTemplate.update(
                "UPDATE users SET name = ?, phone = ?, location = ?, avatar = ? WHERE id = ?",
                user.getName(), user.getPhone(), user.getLocation(), user.getAvatar(), user.getId()
        );
    }

    public int countUsers() {
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Integer.class);
        return count != null ? count : 0;
    }
}
