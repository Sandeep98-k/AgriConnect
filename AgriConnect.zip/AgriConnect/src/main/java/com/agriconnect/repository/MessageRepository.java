package com.agriconnect.repository;

import com.agriconnect.model.Message;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class MessageRepository {

    private final JdbcTemplate jdbcTemplate;

    public MessageRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Message> rowMapper = (rs, rowNum) -> new Message(
            rs.getLong("id"),
            rs.getLong("sender_id"),
            rs.getString("sender_name"),
            rs.getLong("receiver_id"),
            rs.getString("receiver_name"),
            rs.getString("content"),
            rs.getString("sent_at")
    );

    public List<Message> findConversation(Long user1, Long user2) {
        return jdbcTemplate.query(
                "SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY id ASC",
                rowMapper, user1, user2, user2, user1
        );
    }

    public List<Message> findForUser(Long userId) {
        return jdbcTemplate.query("SELECT * FROM messages WHERE sender_id = ? OR receiver_id = ? ORDER BY id DESC", rowMapper, userId, userId);
    }

    public int save(Message message) {
        return jdbcTemplate.update(
                "INSERT INTO messages (sender_id, sender_name, receiver_id, receiver_name, content) VALUES (?, ?, ?, ?, ?)",
                message.getSenderId(), message.getSenderName(), message.getReceiverId(), message.getReceiverName(), message.getContent()
        );
    }
}
