package com.agriconnect.repository;

import com.agriconnect.model.Product;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ProductRepository {

    private final JdbcTemplate jdbcTemplate;

    public ProductRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Product> productRowMapper = (rs, rowNum) -> new Product(
            rs.getLong("id"),
            rs.getLong("farmer_id"),
            rs.getString("farmer_name"),
            rs.getString("title"),
            rs.getString("category"),
            rs.getDouble("price"),
            rs.getInt("quantity"),
            rs.getString("unit"),
            rs.getString("location"),
            rs.getString("description"),
            rs.getString("image_url"),
            rs.getString("created_at")
    );

    public List<Product> findAll() {
        return jdbcTemplate.query("SELECT * FROM products ORDER BY id DESC", productRowMapper);
    }

    public Product findById(Long id) {
        List<Product> products = jdbcTemplate.query("SELECT * FROM products WHERE id = ?", productRowMapper, id);
        return products.isEmpty() ? null : products.get(0);
    }

    public List<Product> findByFarmerId(Long farmerId) {
        return jdbcTemplate.query("SELECT * FROM products WHERE farmer_id = ? ORDER BY id DESC", productRowMapper, farmerId);
    }

    public List<Product> findByCategory(String category) {
        return jdbcTemplate.query("SELECT * FROM products WHERE category = ? ORDER BY id DESC", productRowMapper, category);
    }

    public List<Product> searchProducts(String query) {
        String pattern = "%" + query.toLowerCase() + "%";
        return jdbcTemplate.query("SELECT * FROM products WHERE LOWER(title) LIKE ? OR LOWER(category) LIKE ? OR LOWER(location) LIKE ? ORDER BY id DESC",
                productRowMapper, pattern, pattern, pattern);
    }

    public int save(Product product) {
        return jdbcTemplate.update(
                "INSERT INTO products (farmer_id, farmer_name, title, category, price, quantity, unit, location, description, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                product.getFarmerId(), product.getFarmerName(), product.getTitle(), product.getCategory(), product.getPrice(),
                product.getQuantity(), product.getUnit(), product.getLocation(), product.getDescription(), product.getImageUrl()
        );
    }

    public int updateQuantity(Long productId, int newQuantity) {
        return jdbcTemplate.update("UPDATE products SET quantity = ? WHERE id = ?", newQuantity, productId);
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM products WHERE id = ?", id);
    }

    public int countProducts() {
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM products", Integer.class);
        return count != null ? count : 0;
    }
}
