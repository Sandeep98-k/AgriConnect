package com.agriconnect.repository;

import com.agriconnect.model.MarketPrice;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class MarketPriceRepository {

    private final JdbcTemplate jdbcTemplate;

    public MarketPriceRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<MarketPrice> rowMapper = (rs, rowNum) -> new MarketPrice(
            rs.getLong("id"),
            rs.getString("crop_name"),
            rs.getString("category"),
            rs.getDouble("min_price"),
            rs.getDouble("max_price"),
            rs.getDouble("modal_price"),
            rs.getString("unit"),
            rs.getString("market_location"),
            rs.getString("last_updated")
    );

    public List<MarketPrice> findAll() {
        return jdbcTemplate.query("SELECT * FROM market_prices ORDER BY id ASC", rowMapper);
    }

    public List<MarketPrice> findByLocation(String location) {
        return jdbcTemplate.query("SELECT * FROM market_prices WHERE market_location = ? ORDER BY id ASC", rowMapper, location);
    }
}
