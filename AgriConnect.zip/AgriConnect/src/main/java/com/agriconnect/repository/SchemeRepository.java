package com.agriconnect.repository;

import com.agriconnect.model.Scheme;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SchemeRepository {

    private final JdbcTemplate jdbcTemplate;

    public SchemeRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Scheme> rowMapper = (rs, rowNum) -> new Scheme(
            rs.getLong("id"),
            rs.getString("title"),
            rs.getString("category"),
            rs.getString("description"),
            rs.getString("eligibility"),
            rs.getString("benefits"),
            rs.getString("link")
    );

    public List<Scheme> findAll() {
        return jdbcTemplate.query("SELECT * FROM schemes ORDER BY id ASC", rowMapper);
    }
}
