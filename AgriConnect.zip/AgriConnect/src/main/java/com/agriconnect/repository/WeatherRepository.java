package com.agriconnect.repository;

import com.agriconnect.model.WeatherInfo;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class WeatherRepository {

    private final JdbcTemplate jdbcTemplate;

    public WeatherRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<WeatherInfo> rowMapper = (rs, rowNum) -> new WeatherInfo(
            rs.getLong("id"),
            rs.getString("location"),
            rs.getString("temperature"),
            rs.getString("condition"),
            rs.getString("humidity"),
            rs.getString("wind_speed"),
            rs.getString("rainfall_chance"),
            rs.getString("advisory")
    );

    public List<WeatherInfo> findAll() {
        return jdbcTemplate.query("SELECT * FROM weather_data", rowMapper);
    }
}
