package com.agriconnect.repository;

import com.agriconnect.model.Notification;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class NotificationRepository {

    private final JdbcTemplate jdbcTemplate;

    public NotificationRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Notification> notificationRowMapper = (rs, rowNum) -> new Notification(
            rs.getLong("id"),
            rs.getLong("user_id"),
            rs.getString("title"),
            rs.getString("message"),
            rs.getString("type"),
            rs.getInt("is_read") == 1,
            rs.getString("created_at")
    );

    public int save(Notification notification) {
        return jdbcTemplate.update(
                "INSERT INTO notifications (user_id, title, message, type, is_read) VALUES (?, ?, ?, ?, ?)",
                notification.getUserId(), notification.getTitle(), notification.getMessage(), notification.getType(), notification.isRead() ? 1 : 0
        );
    }

    public List<Notification> findByUserId(Long userId) {
        return jdbcTemplate.query("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC", notificationRowMapper, userId);
    }

    public int markAsRead(Long notificationId) {
        return jdbcTemplate.update("UPDATE notifications SET is_read = 1 WHERE id = ?", notificationId);
    }

    public int getUnreadCount(Long userId) {
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0", Integer.class, userId);
        return count != null ? count : 0;
    }
}
