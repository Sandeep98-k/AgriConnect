package com.agriconnect.repository;

import com.agriconnect.model.Review;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ReviewRepository {

    private final JdbcTemplate jdbcTemplate;

    public ReviewRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Review> rowMapper = (rs, rowNum) -> new Review(
            rs.getLong("id"),
            rs.getLong("reviewer_id"),
            rs.getString("reviewer_name"),
            rs.getLong("target_user_id"),
            rs.getInt("rating"),
            rs.getString("comment"),
            rs.getString("created_at")
    );

    public List<Review> findByTargetUserId(Long targetUserId) {
        return jdbcTemplate.query("SELECT * FROM reviews WHERE target_user_id = ? ORDER BY id DESC", rowMapper, targetUserId);
    }

    public List<Review> findAll() {
        return jdbcTemplate.query("SELECT * FROM reviews ORDER BY id DESC", rowMapper);
    }

    public int save(Review review) {
        return jdbcTemplate.update(
                "INSERT INTO reviews (reviewer_id, reviewer_name, target_user_id, rating, comment) VALUES (?, ?, ?, ?, ?)",
                review.getReviewerId(), review.getReviewerName(), review.getTargetUserId(), review.getRating(), review.getComment()
        );
    }
}
