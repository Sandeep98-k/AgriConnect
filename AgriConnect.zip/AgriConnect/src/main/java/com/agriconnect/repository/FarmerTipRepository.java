package com.agriconnect.repository;

import com.agriconnect.model.FarmerTip;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class FarmerTipRepository {

    private final JdbcTemplate jdbcTemplate;

    public FarmerTipRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<FarmerTip> rowMapper = (rs, rowNum) -> new FarmerTip(
            rs.getLong("id"),
            rs.getString("title"),
            rs.getString("category"),
            rs.getString("content"),
            rs.getString("author"),
            rs.getString("created_at")
    );

    public List<FarmerTip> findAll() {
        return jdbcTemplate.query("SELECT * FROM farmer_tips ORDER BY id DESC", rowMapper);
    }
}
