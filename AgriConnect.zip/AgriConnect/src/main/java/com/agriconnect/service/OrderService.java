package com.agriconnect.service;

import com.agriconnect.model.Notification;
import com.agriconnect.model.Order;
import com.agriconnect.model.Product;
import com.agriconnect.model.User;
import com.agriconnect.repository.NotificationRepository;
import com.agriconnect.repository.OrderRepository;
import com.agriconnect.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final NotificationRepository notificationRepository;

    public OrderService(OrderRepository orderRepository, ProductRepository productRepository, NotificationRepository notificationRepository) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.notificationRepository = notificationRepository;
    }

    @Transactional
    public String processDirectPurchase(User buyer, Long productId, int requestedQty, String deliveryAddress, String paymentMethod) {
        if (buyer == null) {
            return "Please login to purchase products.";
        }

        Product product = productRepository.findById(productId);
        if (product == null) {
            return "Selected product not found.";
        }

        if (requestedQty <= 0) {
            return "Please enter a valid quantity.";
        }

        if (product.getQuantity() < requestedQty) {
            return "Insufficient stock! Only " + product.getQuantity() + " " + product.getUnit() + " available.";
        }

        // 1. Calculate prices
        double unitPrice = product.getPrice();
        double totalPrice = unitPrice * requestedQty;

        // 2. Build and insert order into SQLite
        Order order = new Order();
        order.setBuyerId(buyer.getId());
        order.setBuyerName(buyer.getName());
        order.setFarmerId(product.getFarmerId());
        order.setProductId(product.getId());
        order.setProductTitle(product.getTitle());
        order.setQuantity(requestedQty);
        order.setUnitPrice(unitPrice);
        order.setTotalPrice(totalPrice);
        order.setStatus("CONFIRMED");
        order.setDeliveryAddress(deliveryAddress != null && !deliveryAddress.isBlank() ? deliveryAddress : buyer.getLocation());
        order.setPaymentMethod(paymentMethod != null && !paymentMethod.isBlank() ? paymentMethod : "Cash on Delivery");

        orderRepository.save(order);

        // 3. Decrease product quantity in SQLite
        int updatedQty = product.getQuantity() - requestedQty;
        productRepository.updateQuantity(productId, updatedQty);

        // 4. Create Notification for Farmer
        Notification farmerNotice = new Notification();
        farmerNotice.setUserId(product.getFarmerId());
        farmerNotice.setTitle("New Order Received!");
        farmerNotice.setMessage(buyer.getName() + " bought " + requestedQty + " " + product.getUnit() + " of '" + product.getTitle() + "' for ₹" + String.format("%.2f", totalPrice) + ".");
        farmerNotice.setType("ORDER");
        farmerNotice.setRead(false);
        notificationRepository.save(farmerNotice);

        // 5. Create Notification for Buyer
        Notification buyerNotice = new Notification();
        buyerNotice.setUserId(buyer.getId());
        buyerNotice.setTitle("Order Placed Successfully!");
        buyerNotice.setMessage("Your order for " + requestedQty + " " + product.getUnit() + " of '" + product.getTitle() + "' has been placed successfully.");
        buyerNotice.setType("ORDER");
        buyerNotice.setRead(false);
        notificationRepository.save(buyerNotice);

        return "SUCCESS";
    }
}
