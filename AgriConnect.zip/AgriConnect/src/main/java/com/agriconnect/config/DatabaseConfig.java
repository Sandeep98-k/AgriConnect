package com.agriconnect.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class DatabaseConfig {

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.sqlite.JDBC");
        dataSource.setUrl("jdbc:sqlite:agriconnect.db");
        return dataSource;
    }

    @Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        initializeDatabase(jdbcTemplate);
        return jdbcTemplate;
    }

    private void initializeDatabase(JdbcTemplate jdbcTemplate) {
        // Users table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL,
                phone TEXT,
                location TEXT,
                avatar TEXT
            );
        """);

        // Products table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                farmer_id INTEGER NOT NULL,
                farmer_name TEXT NOT NULL,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                price REAL NOT NULL,
                quantity INTEGER NOT NULL,
                unit TEXT NOT NULL,
                location TEXT NOT NULL,
                description TEXT,
                image_url TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """);

        // Orders table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                buyer_id INTEGER NOT NULL,
                buyer_name TEXT NOT NULL,
                farmer_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_title TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                total_price REAL NOT NULL,
                status TEXT NOT NULL,
                delivery_address TEXT,
                payment_method TEXT,
                order_date DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """);

        // Notifications table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                type TEXT NOT NULL,
                is_read INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """);

        // Recreate Market Prices table with Min, Max, Modal price columns
        jdbcTemplate.execute("DROP TABLE IF EXISTS market_prices;");
        jdbcTemplate.execute("""
            CREATE TABLE market_prices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                crop_name TEXT NOT NULL,
                category TEXT NOT NULL,
                min_price REAL NOT NULL,
                max_price REAL NOT NULL,
                modal_price REAL NOT NULL,
                unit TEXT NOT NULL,
                market_location TEXT NOT NULL,
                last_updated TEXT NOT NULL
            );
        """);

        // Weather table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS weather_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                location TEXT NOT NULL,
                temperature TEXT NOT NULL,
                condition TEXT NOT NULL,
                humidity TEXT NOT NULL,
                wind_speed TEXT NOT NULL,
                rainfall_chance TEXT NOT NULL,
                advisory TEXT NOT NULL
            );
        """);

        // Farmer Tips table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS farmer_tips (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                author TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """);

        // Messages table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER NOT NULL,
                sender_name TEXT NOT NULL,
                receiver_id INTEGER NOT NULL,
                receiver_name TEXT NOT NULL,
                content TEXT NOT NULL,
                sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """);

        // Government Schemes table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS schemes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                eligibility TEXT NOT NULL,
                benefits TEXT NOT NULL,
                link TEXT NOT NULL
            );
        """);

        // Reviews table
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reviewer_id INTEGER NOT NULL,
                reviewer_name TEXT NOT NULL,
                target_user_id INTEGER NOT NULL,
                rating INTEGER NOT NULL,
                comment TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """);

        // Check user count to seed baseline data if users table is empty
        Integer userCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Integer.class);
        if (userCount == null || userCount == 0) {
            seedDefaultUsers(jdbcTemplate);
        }

        // Always re-seed products & market prices to match mockup
        seedMockupData(jdbcTemplate);
    }

    private void seedDefaultUsers(JdbcTemplate jdbc) {
        jdbc.update("INSERT INTO users (name, email, password, role, phone, location, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)",
                "Ramesh Kumar", "farmer@agriconnect.com", "farmer123", "FARMER", "+91 9876543210", "Warangal, Telangana", "https://images.unsplash.com/photo-1544717305-2782549b5136?w=150");
        jdbc.update("INSERT INTO users (name, email, password, role, phone, location, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)",
                "Suresh Sharma", "farmer2@agriconnect.com", "farmer123", "FARMER", "+91 9812345678", "Hanamkonda, Telangana", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150");
        jdbc.update("INSERT INTO users (name, email, password, role, phone, location, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)",
                "Priya Traders", "buyer@agriconnect.com", "buyer123", "BUYER", "+91 9988776655", "Hyderabad, Telangana", "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150");
        jdbc.update("INSERT INTO users (name, email, password, role, phone, location, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)",
                "Agri Admin", "admin@agriconnect.com", "admin123", "ADMIN", "+91 9000000000", "Warangal, Telangana", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150");
    }

    private void seedMockupData(JdbcTemplate jdbc) {
        // Reset products table to match mockup screens
        jdbc.execute("DELETE FROM products;");

        jdbc.update("INSERT INTO products (farmer_id, farmer_name, title, category, price, quantity, unit, location, description, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                1, "Ramesh Kumar", "Tomato", "Vegetables", 25.0, 500, "kg", "Warangal, Telangana",
                "Farm fresh, ripe red tomatoes harvested from organic fields in Warangal.",
                "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600");

        jdbc.update("INSERT INTO products (farmer_id, farmer_name, title, category, price, quantity, unit, location, description, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                1, "Ramesh Kumar", "Potato", "Vegetables", 18.0, 300, "kg", "Warangal, Telangana",
                "High quality soil-fresh potatoes, perfect for storage and commercial cooking.",
                "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=600");

        jdbc.update("INSERT INTO products (farmer_id, farmer_name, title, category, price, quantity, unit, location, description, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                2, "Suresh Sharma", "Onion", "Vegetables", 20.0, 400, "kg", "Hanamkonda, Telangana",
                "Pungent, high-grade red onions dried naturally under sun.",
                "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cf?w=600");

        jdbc.update("INSERT INTO products (farmer_id, farmer_name, title, category, price, quantity, unit, location, description, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                1, "Ramesh Kumar", "Green Chilli", "Vegetables", 40.0, 100, "kg", "Warangal, Telangana",
                "Spicy green chillies freshly picked from healthy green crops.",
                "https://images.unsplash.com/photo-1588880331179-bc9b93a8cb5e?w=600");

        // Seed Market Prices table matching Screen 5
        jdbc.update("INSERT INTO market_prices (crop_name, category, min_price, max_price, modal_price, unit, market_location, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                "Tomato", "Vegetables", 20.0, 28.0, 25.0, "per kg", "Warangal Market", "10 May 2025");
        jdbc.update("INSERT INTO market_prices (crop_name, category, min_price, max_price, modal_price, unit, market_location, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                "Potato", "Vegetables", 15.0, 20.0, 18.0, "per kg", "Warangal Market", "10 May 2025");
        jdbc.update("INSERT INTO market_prices (crop_name, category, min_price, max_price, modal_price, unit, market_location, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                "Onion", "Vegetables", 18.0, 24.0, 20.0, "per kg", "Warangal Market", "10 May 2025");
        jdbc.update("INSERT INTO market_prices (crop_name, category, min_price, max_price, modal_price, unit, market_location, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                "Green Chilli", "Vegetables", 35.0, 45.0, 40.0, "per kg", "Warangal Market", "10 May 2025");
        jdbc.update("INSERT INTO market_prices (crop_name, category, min_price, max_price, modal_price, unit, market_location, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                "Cotton", "Commercial", 6800.0, 7400.0, 7100.0, "per Quintal", "Warangal Market", "10 May 2025");
        jdbc.update("INSERT INTO market_prices (crop_name, category, min_price, max_price, modal_price, unit, market_location, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                "Paddy", "Grains", 2200.0, 2450.0, 2300.0, "per Quintal", "Warangal Market", "10 May 2025");
        jdbc.update("INSERT INTO market_prices (crop_name, category, min_price, max_price, modal_price, unit, market_location, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                "Maize", "Grains", 1700.0, 1950.0, 1800.0, "per Quintal", "Warangal Market", "10 May 2025");

        // Seed Weather Advisory matching Screen 4
        jdbc.execute("DELETE FROM weather_data;");
        jdbc.update("INSERT INTO weather_data (location, temperature, condition, humidity, wind_speed, rainfall_chance, advisory) VALUES (?, ?, ?, ?, ?, ?, ?)",
                "Warangal, Telangana", "28°C", "Partly Cloudy", "65%", "12 km/h", "10%", "Favorable weather for vegetable harvest and crop drying.");

        // Seed Farmer Tips
        jdbc.execute("DELETE FROM farmer_tips;");
        jdbc.update("INSERT INTO farmer_tips (title, category, content, author) VALUES (?, ?, ?, ?)",
                "Soil Fertility Improvement", "Soil Care", "Use vermicompost and crop rotation with legumes to fix nitrogen naturally.", "ICAR Agronomist");
        jdbc.update("INSERT INTO farmer_tips (title, category, content, author) VALUES (?, ?, ?, ?)",
                "Drip Irrigation Benefits", "Irrigation", "Save up to 40% water by installing drip lines for chilli and tomato crops.", "Telangana Agri Dept");

        // Seed Schemes matching Screen 6
        jdbc.execute("DELETE FROM schemes;");
        jdbc.update("INSERT INTO schemes (title, category, description, eligibility, benefits, link) VALUES (?, ?, ?, ?, ?, ?)",
                "PM-KISAN", "Financial",
                "Financial support to landholding farmer families.",
                "Landholding farmers", "Rs. 6000 annually", "https://pmkisan.gov.in");

        jdbc.update("INSERT INTO schemes (title, category, description, eligibility, benefits, link) VALUES (?, ?, ?, ?, ?, ?)",
                "Crop Insurance", "Insurance",
                "Financial protection against crop failure due to weather or pests.",
                "All farmers growing notified crops", "Full risk coverage", "https://pmfby.gov.in");

        jdbc.update("INSERT INTO schemes (title, category, description, eligibility, benefits, link) VALUES (?, ?, ?, ?, ?, ?)",
                "Soil Health Card", "Soil & Fertilizer",
                "Know your soil health and improve crop yield with customized recommendations.",
                "All farm landholders", "Free soil testing card", "https://soilhealth.dac.gov.in");

        jdbc.update("INSERT INTO schemes (title, category, description, eligibility, benefits, link) VALUES (?, ?, ?, ?, ?, ?)",
                "Subsidy Schemes", "Equipment & Subsidies",
                "Government subsidies on seeds, fertilizers, drip irrigation, and farm machinery.",
                "Small & marginal farmers", "Up to 50% subsidy", "https://agricoop.nic.in");
    }
}
