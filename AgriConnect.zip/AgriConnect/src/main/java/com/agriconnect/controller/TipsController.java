package com.agriconnect.controller;

import com.agriconnect.model.FarmerTip;
import com.agriconnect.repository.FarmerTipRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class TipsController {

    private final FarmerTipRepository farmerTipRepository;

    public TipsController(FarmerTipRepository farmerTipRepository) {
        this.farmerTipRepository = farmerTipRepository;
    }

    @GetMapping("/farmer-tips")
    public String viewFarmerTips(Model model) {
        List<FarmerTip> tips = farmerTipRepository.findAll();
        model.addAttribute("tips", tips);
        return "farmer-tips";
    }
}
