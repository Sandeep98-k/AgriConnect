package com.agriconnect.controller;

import com.agriconnect.model.Product;
import com.agriconnect.model.User;
import com.agriconnect.repository.NotificationRepository;
import com.agriconnect.repository.OrderRepository;
import com.agriconnect.repository.ProductRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class DashboardController {

    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;
    private final NotificationRepository notificationRepository;

    public DashboardController(ProductRepository productRepository, OrderRepository orderRepository, NotificationRepository notificationRepository) {
        this.productRepository = productRepository;
        this.orderRepository = orderRepository;
        this.notificationRepository = notificationRepository;
    }

    @GetMapping("/dashboard")
    public String viewDashboard(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            // Default demo login as Ramesh Kumar (Farmer) if visiting dashboard directly
            return "redirect:/demo-login?role=FARMER";
        }

        List<Product> recentListings;
        if ("FARMER".equalsIgnoreCase(currentUser.getRole())) {
            recentListings = productRepository.findByFarmerId(currentUser.getId());
        } else {
            recentListings = productRepository.findAll();
        }

        model.addAttribute("recentListings", recentListings);
        model.addAttribute("totalListingsCount", recentListings.size());
        model.addAttribute("unreadMessagesCount", 5);
        model.addAttribute("totalOrdersCount", orderRepository.countOrders());
        model.addAttribute("monthlyEarnings", "24,560");

        return "dashboard";
    }
}
