package com.agriconnect.controller;

import com.agriconnect.model.Product;
import com.agriconnect.model.User;
import com.agriconnect.repository.ProductRepository;
import com.agriconnect.service.OrderService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class MarketplaceController {

    private final ProductRepository productRepository;
    private final OrderService orderService;

    public MarketplaceController(ProductRepository productRepository, OrderService orderService) {
        this.productRepository = productRepository;
        this.orderService = orderService;
    }

    @GetMapping("/marketplace")
    public String viewMarketplace(@RequestParam(required = false) String category,
                                  @RequestParam(required = false) String search,
                                  Model model) {
        List<Product> products;
        if (search != null && !search.isBlank()) {
            products = productRepository.searchProducts(search.trim());
            model.addAttribute("currentSearch", search);
        } else if (category != null && !category.isBlank() && !"ALL".equalsIgnoreCase(category)) {
            products = productRepository.findByCategory(category.trim());
            model.addAttribute("selectedCategory", category);
        } else {
            products = productRepository.findAll();
        }

        model.addAttribute("products", products);
        return "marketplace";
    }

    @PostMapping("/marketplace/buy-now")
    public String buyNowDirectly(@RequestParam Long productId,
                                 @RequestParam int quantity,
                                 @RequestParam(required = false) String deliveryAddress,
                                 @RequestParam(required = false) String paymentMethod,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please login to purchase products.");
            return "redirect:/login?role=BUYER";
        }

        String result = orderService.processDirectPurchase(currentUser, productId, quantity, deliveryAddress, paymentMethod);
        if ("SUCCESS".equals(result)) {
            redirectAttributes.addFlashAttribute("successMessage", "Order placed successfully! Product stock updated and notifications sent.");
            return "redirect:/orders";
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", result);
            return "redirect:/marketplace";
        }
    }
}
