package com.agriconnect.controller;

import com.agriconnect.model.User;
import com.agriconnect.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    private final UserRepository userRepository;

    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/")
    public String root(HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser != null) {
            return "redirect:/dashboard";
        }
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage(@RequestParam(required = false) String role, Model model) {
        model.addAttribute("selectedRole", role != null ? role.toUpperCase() : "FARMER");
        return "login";
    }

    @PostMapping("/login")
    public String loginProcess(@RequestParam String email,
                               @RequestParam String password,
                               HttpSession session,
                               Model model) {
        User user = userRepository.findByEmail(email);
        if (user == null || !user.getPassword().equals(password)) {
            model.addAttribute("error", "Invalid email or password!");
            return "login";
        }

        session.setAttribute("currentUser", user);

        if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            return "redirect:/admin";
        }
        return "redirect:/dashboard";
    }

    @GetMapping("/demo-login")
    public String demoLogin(@RequestParam String role, HttpSession session) {
        User user = null;
        if ("FARMER".equalsIgnoreCase(role)) {
            user = userRepository.findByEmail("farmer@agriconnect.com");
        } else if ("BUYER".equalsIgnoreCase(role)) {
            user = userRepository.findByEmail("buyer@agriconnect.com");
        } else if ("ADMIN".equalsIgnoreCase(role)) {
            user = userRepository.findByEmail("admin@agriconnect.com");
        }

        if (user != null) {
            session.setAttribute("currentUser", user);
        }

        if ("ADMIN".equalsIgnoreCase(role)) {
            return "redirect:/admin";
        }
        return "redirect:/dashboard";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String registerProcess(@RequestParam String name,
                                  @RequestParam String email,
                                  @RequestParam String password,
                                  @RequestParam String role,
                                  @RequestParam String phone,
                                  @RequestParam String location,
                                  HttpSession session,
                                  Model model) {
        if (userRepository.findByEmail(email) != null) {
            model.addAttribute("error", "Email is already registered!");
            return "register";
        }

        User newUser = new User();
        newUser.setName(name);
        newUser.setEmail(email);
        newUser.setPassword(password);
        newUser.setRole(role.toUpperCase());
        newUser.setPhone(phone);
        newUser.setLocation(location);
        newUser.setAvatar("https://images.unsplash.com/photo-1544717305-2782549b5136?w=150");

        userRepository.save(newUser);
        User savedUser = userRepository.findByEmail(email);
        session.setAttribute("currentUser", savedUser);

        return "redirect:/dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
