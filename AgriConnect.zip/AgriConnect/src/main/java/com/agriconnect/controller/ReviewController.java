package com.agriconnect.controller;

import com.agriconnect.model.Review;
import com.agriconnect.model.User;
import com.agriconnect.repository.ReviewRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class ReviewController {

    private final ReviewRepository reviewRepository;

    public ReviewController(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    @GetMapping("/reviews")
    public String viewReviews(Model model) {
        List<Review> reviews = reviewRepository.findAll();
        model.addAttribute("reviews", reviews);
        return "reviews";
    }

    @PostMapping("/reviews/add")
    public String addReview(@RequestParam Long targetUserId,
                            @RequestParam Integer rating,
                            @RequestParam String comment,
                            HttpSession session,
                            RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        Review review = new Review();
        review.setReviewerId(currentUser.getId());
        review.setReviewerName(currentUser.getName());
        review.setTargetUserId(targetUserId);
        review.setRating(rating);
        review.setComment(comment);

        reviewRepository.save(review);
        redirectAttributes.addFlashAttribute("successMessage", "Thank you for your feedback! Review submitted.");
        return "redirect:/reviews";
    }
}
