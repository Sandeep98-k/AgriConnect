package com.agriconnect.controller;

import com.agriconnect.model.MarketPrice;
import com.agriconnect.repository.MarketPriceRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MarketPricesController {

    private final MarketPriceRepository marketPriceRepository;

    public MarketPricesController(MarketPriceRepository marketPriceRepository) {
        this.marketPriceRepository = marketPriceRepository;
    }

    @GetMapping("/market-prices")
    public String viewMarketPrices(Model model) {
        List<MarketPrice> marketPrices = marketPriceRepository.findAll();
        model.addAttribute("marketPrices", marketPrices);
        return "market-prices";
    }
}
