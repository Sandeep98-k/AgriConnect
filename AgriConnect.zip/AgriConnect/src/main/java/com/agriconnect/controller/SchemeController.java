package com.agriconnect.controller;

import com.agriconnect.model.Scheme;
import com.agriconnect.repository.SchemeRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class SchemeController {

    private final SchemeRepository schemeRepository;

    public SchemeController(SchemeRepository schemeRepository) {
        this.schemeRepository = schemeRepository;
    }

    @GetMapping("/schemes")
    public String viewSchemes(Model model) {
        List<Scheme> schemes = schemeRepository.findAll();
        model.addAttribute("schemes", schemes);
        return "schemes";
    }
}
