package com.agriconnect.controller;

import com.agriconnect.model.Message;
import com.agriconnect.model.User;
import com.agriconnect.repository.MessageRepository;
import com.agriconnect.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MessageController {

    private final MessageRepository messageRepository;
    private final UserRepository userRepository;

    public MessageController(MessageRepository messageRepository, UserRepository userRepository) {
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/messages")
    public String viewMessages(@RequestParam(required = false) Long receiverId, HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        List<User> allUsers = userRepository.findAll();
        model.addAttribute("allUsers", allUsers);

        if (receiverId != null) {
            User receiver = userRepository.findById(receiverId);
            model.addAttribute("selectedReceiver", receiver);
            List<Message> conversation = messageRepository.findConversation(currentUser.getId(), receiverId);
            model.addAttribute("conversation", conversation);
        } else {
            List<Message> userMessages = messageRepository.findForUser(currentUser.getId());
            model.addAttribute("recentMessages", userMessages);
        }

        return "messages";
    }

    @PostMapping("/messages/send")
    public String sendMessage(@RequestParam Long receiverId,
                              @RequestParam String content,
                              HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        User receiver = userRepository.findById(receiverId);
        if (receiver != null && content != null && !content.isBlank()) {
            Message message = new Message();
            message.setSenderId(currentUser.getId());
            message.setSenderName(currentUser.getName());
            message.setReceiverId(receiver.getId());
            message.setReceiverName(receiver.getName());
            message.setContent(content.trim());
            messageRepository.save(message);
        }

        return "redirect:/messages?receiverId=" + receiverId;
    }
}
