package com.agriconnect.controller;

import com.agriconnect.model.WeatherInfo;
import com.agriconnect.repository.WeatherRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class WeatherController {

    private final WeatherRepository weatherRepository;

    public WeatherController(WeatherRepository weatherRepository) {
        this.weatherRepository = weatherRepository;
    }

    @GetMapping("/weather")
    public String viewWeather(Model model) {
        List<WeatherInfo> weatherList = weatherRepository.findAll();
        model.addAttribute("weatherList", weatherList);
        return "weather";
    }
}
