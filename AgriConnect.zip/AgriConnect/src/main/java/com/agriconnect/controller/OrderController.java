package com.agriconnect.controller;

import com.agriconnect.model.Order;
import com.agriconnect.model.User;
import com.agriconnect.repository.OrderRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class OrderController {

    private final OrderRepository orderRepository;

    public OrderController(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @GetMapping("/orders")
    public String viewOrders(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        List<Order> orders;
        if ("FARMER".equalsIgnoreCase(currentUser.getRole())) {
            orders = orderRepository.findByFarmerId(currentUser.getId());
        } else if ("ADMIN".equalsIgnoreCase(currentUser.getRole())) {
            orders = orderRepository.findAll();
        } else {
            orders = orderRepository.findByBuyerId(currentUser.getId());
        }

        model.addAttribute("orders", orders);
        return "orders";
    }

    @PostMapping("/orders/update-status")
    public String updateOrderStatus(@RequestParam Long orderId,
                                    @RequestParam String status,
                                    HttpSession session,
                                    RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        orderRepository.updateStatus(orderId, status);
        redirectAttributes.addFlashAttribute("successMessage", "Order #" + orderId + " status updated to " + status + ".");
        return "redirect:/orders";
    }
}
