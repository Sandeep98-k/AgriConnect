package com.agriconnect.controller;

import com.agriconnect.model.User;
import com.agriconnect.repository.NotificationRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalControllerAdvice {

    private final NotificationRepository notificationRepository;

    public GlobalControllerAdvice(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @ModelAttribute
    public void addGlobalAttributes(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser != null) {
            model.addAttribute("currentUser", currentUser);
            int unreadCount = notificationRepository.getUnreadCount(currentUser.getId());
            model.addAttribute("unreadCount", unreadCount);
        } else {
            model.addAttribute("unreadCount", 0);
        }
    }
}
