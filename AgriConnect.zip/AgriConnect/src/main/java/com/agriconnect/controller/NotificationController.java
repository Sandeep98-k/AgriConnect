package com.agriconnect.controller;

import com.agriconnect.model.Notification;
import com.agriconnect.model.User;
import com.agriconnect.repository.NotificationRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class NotificationController {

    private final NotificationRepository notificationRepository;

    public NotificationController(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @GetMapping("/notifications")
    public String viewNotifications(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        List<Notification> notifications = notificationRepository.findByUserId(currentUser.getId());
        model.addAttribute("notifications", notifications);
        return "notifications";
    }

    @PostMapping("/notifications/mark-read")
    public String markRead(@RequestParam Long notificationId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        notificationRepository.markAsRead(notificationId);
        return "redirect:/notifications";
    }
}
