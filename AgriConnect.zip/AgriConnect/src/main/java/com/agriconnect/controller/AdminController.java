package com.agriconnect.controller;

import com.agriconnect.model.User;
import com.agriconnect.repository.OrderRepository;
import com.agriconnect.repository.ProductRepository;
import com.agriconnect.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;

    public AdminController(UserRepository userRepository, ProductRepository productRepository, OrderRepository orderRepository) {
        this.userRepository = userRepository;
        this.productRepository = productRepository;
        this.orderRepository = orderRepository;
    }

    @GetMapping("/admin")
    public String adminDashboard(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"ADMIN".equalsIgnoreCase(currentUser.getRole())) {
            return "redirect:/login?role=ADMIN";
        }

        model.addAttribute("totalUsers", userRepository.countUsers());
        model.addAttribute("totalProducts", productRepository.countProducts());
        model.addAttribute("totalOrders", orderRepository.countOrders());

        model.addAttribute("allUsers", userRepository.findAll());
        model.addAttribute("allProducts", productRepository.findAll());
        model.addAttribute("allOrders", orderRepository.findAll());

        return "admin-dashboard";
    }
}
