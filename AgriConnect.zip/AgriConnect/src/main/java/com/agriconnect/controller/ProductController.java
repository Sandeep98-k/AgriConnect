package com.agriconnect.controller;

import com.agriconnect.model.Product;
import com.agriconnect.model.User;
import com.agriconnect.repository.ProductRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ProductController {

    private final ProductRepository productRepository;

    public ProductController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @GetMapping("/sell-produce")
    public String sellProduceForm(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login?role=FARMER";
        }
        return "sell-produce";
    }

    @PostMapping("/sell-produce")
    public String saveProduce(@RequestParam String title,
                              @RequestParam String category,
                              @RequestParam Double price,
                              @RequestParam Integer quantity,
                              @RequestParam String unit,
                              @RequestParam String location,
                              @RequestParam String description,
                              @RequestParam(required = false) String imageUrl,
                              HttpSession session,
                              RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login?role=FARMER";
        }

        Product product = new Product();
        product.setFarmerId(currentUser.getId());
        product.setFarmerName(currentUser.getName());
        product.setTitle(title);
        product.setCategory(category);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setUnit(unit);
        product.setLocation(location);
        product.setDescription(description);
        
        if (imageUrl != null && !imageUrl.isBlank()) {
            product.setImageUrl(imageUrl);
        } else {
            // Default image based on category
            if ("Grains".equalsIgnoreCase(category)) {
                product.setImageUrl("https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600");
            } else if ("Vegetables".equalsIgnoreCase(category)) {
                product.setImageUrl("https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600");
            } else if ("Fruits".equalsIgnoreCase(category)) {
                product.setImageUrl("https://images.unsplash.com/photo-1553279768-865429fa0078?w=600");
            } else {
                product.setImageUrl("https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=600");
            }
        }

        productRepository.save(product);
        redirectAttributes.addFlashAttribute("successMessage", "Crop produce listed successfully in the Marketplace!");
        return "redirect:/marketplace";
    }
}
