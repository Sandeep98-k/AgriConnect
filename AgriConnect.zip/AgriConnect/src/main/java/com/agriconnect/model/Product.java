package com.agriconnect.model;

import java.time.LocalDateTime;

public class Product {
    private Long id;
    private Long farmerId;
    private String farmerName;
    private String title;
    private String category;
    private Double price;
    private Integer quantity;
    private String unit;
    private String location;
    private String description;
    private String imageUrl;
    private String createdAt;

    public Product() {}

    public Product(Long id, Long farmerId, String farmerName, String title, String category, Double price, Integer quantity, String unit, String location, String description, String imageUrl, String createdAt) {
        this.id = id;
        this.farmerId = farmerId;
        this.farmerName = farmerName;
        this.title = title;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
        this.unit = unit;
        this.location = location;
        this.description = description;
        this.imageUrl = imageUrl;
        this.createdAt = createdAt;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getFarmerId() { return farmerId; }
    public void setFarmerId(Long farmerId) { this.farmerId = farmerId; }

    public String getFarmerName() { return farmerName; }
    public void setFarmerName(String farmerName) { this.farmerName = farmerName; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
