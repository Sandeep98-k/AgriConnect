package com.agriconnect.model;

public class MarketPrice {
    private Long id;
    private String cropName;
    private String category;
    private Double minPrice;
    private Double maxPrice;
    private Double modalPrice;
    private String unit;
    private String marketLocation;
    private String lastUpdated;

    public MarketPrice() {}

    public MarketPrice(Long id, String cropName, String category, Double minPrice, Double maxPrice, Double modalPrice, String unit, String marketLocation, String lastUpdated) {
        this.id = id;
        this.cropName = cropName;
        this.category = category;
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
        this.modalPrice = modalPrice;
        this.unit = unit;
        this.marketLocation = marketLocation;
        this.lastUpdated = lastUpdated;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCropName() { return cropName; }
    public void setCropName(String cropName) { this.cropName = cropName; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public Double getMinPrice() { return minPrice; }
    public void setMinPrice(Double minPrice) { this.minPrice = minPrice; }

    public Double getMaxPrice() { return maxPrice; }
    public void setMaxPrice(Double maxPrice) { this.maxPrice = maxPrice; }

    public Double getModalPrice() { return modalPrice; }
    public void setModalPrice(Double modalPrice) { this.modalPrice = modalPrice; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getMarketLocation() { return marketLocation; }
    public void setMarketLocation(String marketLocation) { this.marketLocation = marketLocation; }

    public String getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(String lastUpdated) { this.lastUpdated = lastUpdated; }
}
