package com.agriconnect.model;

public class WeatherInfo {
    private Long id;
    private String location;
    private String temperature;
    private String condition;
    private String humidity;
    private String windSpeed;
    private String rainfallChance;
    private String advisory;

    public WeatherInfo() {}

    public WeatherInfo(Long id, String location, String temperature, String condition, String humidity, String windSpeed, String rainfallChance, String advisory) {
        this.id = id;
        this.location = location;
        this.temperature = temperature;
        this.condition = condition;
        this.humidity = humidity;
        this.windSpeed = windSpeed;
        this.rainfallChance = rainfallChance;
        this.advisory = advisory;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getTemperature() { return temperature; }
    public void setTemperature(String temperature) { this.temperature = temperature; }

    public String getCondition() { return condition; }
    public void setCondition(String condition) { this.condition = condition; }

    public String getHumidity() { return humidity; }
    public void setHumidity(String humidity) { this.humidity = humidity; }

    public String getWindSpeed() { return windSpeed; }
    public void setWindSpeed(String windSpeed) { this.windSpeed = windSpeed; }

    public String getRainfallChance() { return rainfallChance; }
    public void setRainfallChance(String rainfallChance) { this.rainfallChance = rainfallChance; }

    public String getAdvisory() { return advisory; }
    public void setAdvisory(String advisory) { this.advisory = advisory; }
}
