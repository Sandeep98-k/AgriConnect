package com.agriconnect.model;

public class Scheme {
    private Long id;
    private String title;
    private String category;
    private String description;
    private String eligibility;
    private String benefits;
    private String link;

    public Scheme() {}

    public Scheme(Long id, String title, String category, String description, String eligibility, String benefits, String link) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.description = description;
        this.eligibility = eligibility;
        this.benefits = benefits;
        this.link = link;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getEligibility() { return eligibility; }
    public void setEligibility(String eligibility) { this.eligibility = eligibility; }

    public String getBenefits() { return benefits; }
    public void setBenefits(String benefits) { this.benefits = benefits; }

    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }
}
